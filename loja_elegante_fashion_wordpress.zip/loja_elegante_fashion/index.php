<?php get_header(); ?>
<section class="hero">
<h1>Moda, beleza e elegância</h1>
<p>Roupas, calçados e perfumes selecionados para você.</p>
<a class="btn" href="#">Ver produtos</a>
</section>
<div class="products">
<div class="card"><h3>Roupas</h3><p>Coleções modernas</p></div>
<div class="card"><h3>Calçados</h3><p>Estilo e conforto</p></div>
<div class="card"><h3>Perfumes</h3><p>Fragrâncias especiais</p></div>
</div>
<a class="whatsapp" href="https://wa.me/">WhatsApp</a>
<?php get_footer(); ?>