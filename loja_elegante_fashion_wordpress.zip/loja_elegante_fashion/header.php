<!doctype html><html><head><?php wp_head(); ?></head><body>
<header class="header"><div class="logo">SUA LOJA</div>
<nav class="menu"><a href="#">Início</a><a href="#">Produtos</a><a href="#">Login</a></nav></header>